## Requirements
* Code Composer Studio - https://www.ti.com/tool/CCSTUDIO#downloads 

## Update CCS with CC35XXE support
* Copy content in current folder into <CCS_INSTALL_DIR>/ccs/ccs_base
